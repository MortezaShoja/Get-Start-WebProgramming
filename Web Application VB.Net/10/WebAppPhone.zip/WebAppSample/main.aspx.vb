Public Class main
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.sdaVA = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlConnection1 = New System.Data.SqlClient.SqlConnection
        Me.DsVA1 = New WebAppSample.dsVA
        CType(Me.DsVA1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'sdaVA
        '
        Me.sdaVA.SelectCommand = Me.SqlSelectCommand1
        Me.sdaVA.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Employees", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("EmployeeID", "EmployeeID"), New System.Data.Common.DataColumnMapping("LastName", "LastName"), New System.Data.Common.DataColumnMapping("FirstName", "FirstName")})})
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT EmployeeID, LastName, FirstName FROM Employees"
        Me.SqlSelectCommand1.Connection = Me.SqlConnection1
        '
        'SqlConnection1
        '
        Me.SqlConnection1.ConnectionString = "workstation id=""EWQ-403470410F3"";packet size=4096;user id=sa;data source=""."";pers" & _
        "ist security info=True;initial catalog=Northwind;password="
        '
        'DsVA1
        '
        Me.DsVA1.DataSetName = "dsVA"
        Me.DsVA1.Locale = New System.Globalization.CultureInfo("en-US")
        CType(Me.DsVA1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Protected WithEvents pnlAdd As System.Web.UI.WebControls.Panel
    Protected WithEvents txtF As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtN As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtP As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnA As System.Web.UI.WebControls.Button
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents dbgVA As System.Web.UI.WebControls.DataGrid
    Protected WithEvents sdaVA As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlConnection1 As System.Data.SqlClient.SqlConnection
    Protected WithEvents DsVA1 As WebAppSample.dsVA

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Select Case Request.QueryString.Item("action")
            Case Is = "A"
                pnlAdd.Visible = True
            Case Is = "VA"
                Panel1.Visible = True
                dbgVA.Visible = True
                sdaVA.Fill(DsVA1)
                dbgVA.DataBind()
        End Select
    End Sub
End Class
